import { reactive } from './reactive'
import { effect } from './effect'
import { computed } from './computed'
export default {
  reactive, effect, computed
}